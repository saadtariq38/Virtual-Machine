public class OS {

       Memory memory = new Memory();    //init the memory for all processes
       RegisterStorage  regStorage = new RegisterStorage(); //init the registers for all processes
       
}
